package com.dmhashanmd.slpd.utils.interfaces;

public interface CallBack {
    void onSuccess();


    void onFail(String massage);
}
