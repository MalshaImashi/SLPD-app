package com.dmhashanmd.slpd.utils;

public interface SharedPreferencesConst {
    String ID = "ID";
    String EMAIL = "EMAIL";
    String NAME = "NAME";
    String DOB = "DOB";
    String GENDER = "GENDER";
    String COMPANY = "COMPANY";
    String POSITION = "POSITION";

}
