package com.dmhashanmd.slpd.profile.model;


import com.dmhashanmd.slpd.profile.controller.ProfileController;

public class ProfileModel {
    private ProfileController controller;
    int i = 0;

    public ProfileModel(ProfileController controller) {
        this.controller = controller;
    }


}
